package com.adotemais.adotemudeumavidaapp.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.adotemais.adotemudeumavidaapp.R;
import com.adotemais.adotemudeumavidaapp.helper.Permissoes;
import com.santalu.maskara.widget.MaskEditText;

import java.util.ArrayList;
import java.util.List;

public class RegistarAnuncioActivity extends AppCompatActivity

    implements  View.OnClickListener {


    private EditText campoNome, campoDescricao, campoEmail;
    private ImageView imagem1, imagem2, imagem3;
    private Spinner campoDistrito, campoCanil, campoRaca, campoPelo, campoSexo, campoPorte;
    private MaskEditText campoTelefone;

    private String[] permissoes = new String[]{
            Manifest.permission.READ_EXTERNAL_STORAGE
    };
    private List<String> listaFotosRecuperadas = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registar_anuncio);

        //validar permissões
        Permissoes.validarPermissoes(permissoes, this, 1);

        inicializarComponentes();

        carregarDadosSpiner();
    }

    public void guardarAnuncio(){

        String distrito = campoDistrito.getSelectedItem().toString();
        String canil = campoCanil.getSelectedItem().toString();
        String porte = campoPorte.getSelectedItem().toString();
        String pelo = campoPelo.getSelectedItem().toString();
        String sexo = campoSexo.getSelectedItem().toString();
        String nomeCao = campoNome.getText().toString();
        String descricao = campoDescricao.getText().toString();
        String tef = campoTelefone.getText().toString();
        String email = campoEmail.getText().toString();


    }


    public void validaDadosAnuncio(View view){

       String distrito = campoDistrito.getSelectedItem().toString();
       String canil = campoCanil.getSelectedItem().toString();
       String porte = campoPorte.getSelectedItem().toString();
       String pelo = campoPelo.getSelectedItem().toString();
       String sexo = campoSexo.getSelectedItem().toString();
       String nomeCao = campoNome.getText().toString();
       String descricao = campoDescricao.getText().toString();
       String tef = campoTelefone.getText().toString();
       String email = campoEmail.getText().toString();


       if(listaFotosRecuperadas.size()!= 0) {

           if(!distrito.isEmpty()){
               if(!canil.isEmpty()){
                   if(!porte.isEmpty()){
                       if(!pelo.isEmpty()){
                           if(!sexo.isEmpty()){
                               if(!nomeCao.isEmpty()){
                                   if(!descricao.isEmpty()){
                                       if(!tef.isEmpty()){
                                           if(!email.isEmpty()){
                                           }else{

                                               exibirMensagemEroo(" Preencha o campo email!");
                                           }
                                       }else{

                                           exibirMensagemEroo(" Preencha o campo Telefone!");
                                       }
                                   }else{

                                       exibirMensagemEroo(" Preencha o campo descricao!");
                                   }
                               }else{

                                   exibirMensagemEroo(" Preencha o campo nome do animal!");
                               }
                           }else{

                               exibirMensagemEroo(" Preencha o campo sexo!");
                           }
                       }else{

                           exibirMensagemEroo(" Preencha o campo pelo!");
                       }
                   }else{

                       exibirMensagemEroo(" Preencha o campo porte!");
                   }
               }else{

                   exibirMensagemEroo(" Preencha o campo canil!");
               }
           }else{

               exibirMensagemEroo(" Prencha o campo distrito!");
           }


       }else{

           exibirMensagemEroo(" Selecione pelo menos uma foto!");

       }

    }

    private void exibirMensagemEroo(String mensagem){
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();

    }





    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.image1 :
                escolherImagem( 1);
                break;
            case R.id.image2 :
                escolherImagem( 2);
                break;
            case R.id.image3 :
                escolherImagem( 3);
                break;

        }

    }

    public void escolherImagem(int requestCode) {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i,requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK ){

            //recuperar imagem
            Uri imagemSelecionada = data.getData();
            String caminhoImagem = imagemSelecionada.toString();

            //Configura imagem no ImageView

            if(requestCode == 1) {

                imagem1.setImageURI(imagemSelecionada);
            }else if(resultCode == 2 ){
                imagem2.setImageURI(imagemSelecionada);
            }else if(resultCode == 3 ){
                imagem3.setImageURI(imagemSelecionada);
            }
            listaFotosRecuperadas.add( caminhoImagem);


        }
    }

    private void carregarDadosSpiner(){

        //Configura spinner de distritos



        String[] distritos = getResources().getStringArray(R.array.distritos);
        ArrayAdapter<String> adapterDistritos = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, distritos);
        adapterDistritos.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        campoDistrito.setAdapter(adapterDistritos);


        String[] canils = getResources().getStringArray(R.array.canil);
        ArrayAdapter<String> adapterCanil = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, canils);
        adapterCanil.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        campoCanil.setAdapter(adapterCanil);


        String[] sexos = getResources().getStringArray(R.array.sexo);
        ArrayAdapter<String> adapterSexo = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,sexos);
        adapterSexo.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        campoSexo.setAdapter(adapterSexo);

        String[] pelos = getResources().getStringArray(R.array.pelos);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,
                pelos);
        adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        campoPelo.setAdapter(adapter);

        String[] racas = getResources().getStringArray(R.array.racas);
        ArrayAdapter<String> adapterRacas = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,
                racas);
        adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        campoRaca.setAdapter(adapterRacas);

        String[] portes = getResources().getStringArray(R.array.portes);
        ArrayAdapter<String> adapterPortes = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,
                portes);
        adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        campoPorte.setAdapter(adapterPortes);



        //Configura spinner de canil


    }

    private void inicializarComponentes(){

     campoNome = findViewById(R.id.editNome);
     campoDescricao = findViewById(R.id.editDescricao);
     campoEmail = findViewById(R.id.editEmail);
     campoTelefone = findViewById(R.id.editTelefone);
     campoDistrito = findViewById(R.id.spinnerDistrito);
     campoCanil = findViewById(R.id.spinnerCanil);
     campoSexo = findViewById(R.id.spinnerSexo);
     campoRaca = findViewById(R.id.spinnerRaca);
     campoPelo = findViewById(R.id.spinnerPelo);
     campoPorte = findViewById(R.id.spinnerPorte);
     imagem1 = findViewById(R.id.image1);
     imagem2 = findViewById(R.id.image2);
     imagem3 = findViewById(R.id.image3);
     imagem1.setOnClickListener(this);
     imagem2.setOnClickListener(this);
     imagem3.setOnClickListener(this);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        for( int permissaoResultado : grantResults ){

            if(permissaoResultado== PackageManager.PERMISSION_DENIED){
                alertaValidacaoPermissao();
            }

        }
    }

    private void alertaValidacaoPermissao(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissões Negadas");
        builder.setMessage("Para utilizar o app é necessário aceitar as permissões");
        builder.setCancelable(false);
        builder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
               finish();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

    }
}
